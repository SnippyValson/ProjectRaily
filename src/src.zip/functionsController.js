var functions = require('./functions/handleTrainStatusRequest');

console.log('Entering Functions Controller');
